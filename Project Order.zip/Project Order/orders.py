from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from enum import Enum
from uuid import uuid4
from datetime import datetime

app = FastAPI()

# Enum for order status
class OrderStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

# Model for order items
class OrderItem(BaseModel):
    product_id: str
    name: str
    quantity: int
    price: float

# Model for creating an order
class OrderCreate(BaseModel):
    customer_name: str
    items: List[OrderItem]
    discount: Optional[float] = 0.0  # Discount percentage (e.g., 10 for 10%)
    tax_rate: Optional[float] = 0.0  # Tax percentage (e.g., 8 for 8%)

# Model for order response
class OrderResponse(OrderCreate):
    id: str
    status: OrderStatus
    created_at: datetime
    updated_at: datetime
    subtotal: float
    discount_amount: float
    tax_amount: float
    total: float

# In-memory storage
orders_db = {}

# Helper function to calculate order totals
def calculate_order_totals(items: List[OrderItem], discount: float, tax_rate: float) -> dict:
    subtotal = sum(item.price * item.quantity for item in items)
    discount_amount = subtotal * (discount / 100)
    subtotal_after_discount = subtotal - discount_amount
    tax_amount = subtotal_after_discount * (tax_rate / 100)
    total = subtotal_after_discount + tax_amount
    
    return {
        "subtotal": round(subtotal, 2),
        "discount_amount": round(discount_amount, 2),
        "tax_amount": round(tax_amount, 2),
        "total": round(total, 2)
    }

@app.get("/")
def read_root():
    return {"message": "FastAPI is running . Visit /docs for API Documenatation."}

# Create a new order
@app.post("/orders/", response_model=OrderResponse)
async def create_order(order: OrderCreate):
    order_id = str(uuid4())
    now = datetime.now()
    
    totals = calculate_order_totals(order.items, order.discount, order.tax_rate)
    
    order_data = {
        "id": order_id,
        "customer_name": order.customer_name,
        "items": [item.dict() for item in order.items],
        "status": OrderStatus.COMPLETED,
        "created_at": now,
        "updated_at": now,
        "discount": order.discount,
        "tax_rate": order.tax_rate,
        **totals
    }
    
    orders_db[order_id] = order_data
    return order_data

# Get all orders
@app.get("/orders/", response_model=List[OrderResponse])
async def get_all_orders():
    return list(orders_db.values())

# Get a single order by ID
@app.get("/orders/{order_id}", response_model=OrderResponse)
async def get_order(order_id: str):
    if order_id not in orders_db:
        raise HTTPException(status_code=404, detail="Order not found")
    return orders_db[order_id]

# Update order status
@app.patch("/orders/{order_id}/status", response_model=OrderResponse)
async def update_order_status(order_id: str, status: OrderStatus):
    if order_id not in orders_db:
        raise HTTPException(status_code=404, detail="Order not found")
    
    orders_db[order_id]["status"] = status
    orders_db[order_id]["updated_at"] = datetime.now()
    
    return orders_db[order_id]

# Delete an order by ID
@app.delete("/orders/{order_id}", status_code=204)
async def delete_order(order_id: str):
    if order_id not in orders_db:
        raise HTTPException(status_code=404, detail="Order not found")
    del orders_db[order_id]
    return

# Get order summary
@app.get("/orders/{order_id}", response_model=OrderResponse)
async def get_order_summary(order_id: str):
    total_orders = len(orders_db)
    total_value = sum(order["total"] for order in orders_db.values())
    total_pending = sum(1 for order in orders_db.values() if order["status"] == OrderStatus.PENDING)
    total_processing = sum(1 for order in orders_db.values() if order["status"] == OrderStatus.PROCESSING)
    total_completed = sum(1 for order in orders_db.values() if order["status"] == OrderStatus.COMPLETED)
    total_cancelled = sum(1 for order in orders_db.values() if order["status"] == OrderStatus.CANCELLED)
    
    return {
        "total_orders": total_orders,
        "total_value": round(total_value, 2),
        "status_counts": {
            "pending": total_pending,
            "processing": total_processing,
            "completed": total_completed,
            "cancelled": total_cancelled
        }
    }